import React from 'react';
import './styles/navbts.css';

function NavBts(props){
    return(
        <div>
            <li>
                <a href="index.html"><strong>{props.name}</strong></a>
            </li>
        </div>
    )
}

export default NavBts;