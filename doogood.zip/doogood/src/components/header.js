import companyLogo from './img/Logo.png';

function Header(props){
    return(
        <div class="header-container">
            <header>
                <div className="hero-image">
                    <img src={companyLogo} alt="BigCo Inc. logo"/>
                </div>
                <div class="hero-content">
                    <h1>doogood</h1>
                    <p>
                        where philanthropists meets NGO's.
                    </p>
                </div>
            </header>
        </div>
    )
}

export default Header;